# covid19-monitor

<h1>Sistem Informasi Monitoring COVID-19</h1>
<br>
Syarat Penggunaan <br>
1. Pastikan Versi PHP Anda 5 atau lebih, karena sistem ini menggunakan MySQLi atau anda bisa melakukan migrasi terlebih dahulu <br>
   https://www.jagoanhosting.com/tutorial/uncategorized/tutorial-mengubah-script-mysql-menjadi-mysqli <br>
2. Komputer anda sudah terinstall web server <br>
  https://www.dewaweb.com/blog/5-web-server-gratis-untuk-deployment-website/ <br>
3. Komputer anda sudah terinstall database MySQL <br>
  https://www.duniailkom.com/tutorial-mysql-download-install-dan-setingan-awal-mysql/ <br>

Atau Komputer anda sudah terinstall package software yang sudah terdiri dari ketiga poin di atas seperti XAMPP, jangan lupa perhatikan verisi PHP! Anda Bisa mendownload nya disini <br>
https://www.apachefriends.org/download.html <br><br>

Jika Semuanya Sudah Terinstall,
1. Nyalakan Web Server Anda <br>
2. Jika Menggunakan XAMPP silahkan aktifkan APACHE webserver dan juga database MySQL nya <br
3. Copy file ini ke dalam folder htdocs, secara default folder tersebut ada pada Drive C:/xampp/htdocs/ <br>
4. Buka <b> localhost/phpmyadmin </b> pada browser yang ada gunakan <br>
5. Buat Database baru dengan nama <b>db_monitoring_covid19</b>. Ingat nama harus sesuai, jika tidak maka sistem tidak akan berjalan <br>
6. Import database yang ada pada folder <b>db</b> pada file sistem ini yang ada sudah download yang bernama : <b>db_monitoring_covid19.sql</b>
7. Jika Semuanya Berhasil, anda dapat membuat <b>localhost/covid19-mon/</b> untuk dapat memulai menggunakan sistem ini

<hr>
<h1>Username  : superadmin</h1><br>
<h1>Password  : admin</h1>
