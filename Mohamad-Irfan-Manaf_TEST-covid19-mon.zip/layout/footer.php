    <!-- bootstrap js -->
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
    <!-- feather icon -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js"
        integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous">
    </script>
    <!-- chart js  -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
    <!-- chart line -->
    <script src="assets/dist/js/chartline.js"></script>
    <!-- chart line -->
    <script src="assets/dist/js/chartpie1.js"></script>
    <!-- chart line -->
    <script src="assets/dist/js/chartpie2.js"></script>
</body>

</html>